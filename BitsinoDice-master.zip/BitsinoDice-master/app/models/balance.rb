class Balance < ActiveRecord::Base
end
